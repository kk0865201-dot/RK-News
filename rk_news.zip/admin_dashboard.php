<?php

require_once 'db_connect.php';

session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'Admin') {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_content'])) {
    $section = $_POST['section'] ?? '';
    $content = $_POST['content'] ?? '';
    if ($section && $content !== '') {
        $stmt = $pdo->prepare('
            INSERT INTO page_content (section, content)
            VALUES (?, ?)
            ON DUPLICATE KEY UPDATE content = ?
        ');
        $stmt->execute([$section, $content, $content]);
    }
    header('Location: admin_dashboard.php');
    exit;
}

 $news = $pdo->query('SELECT * FROM news ORDER BY created_at DESC')->fetchAll();
 $comments = $pdo->query('SELECT c.*, u.name, n.title FROM comments c JOIN users u ON c.user_id = u.id JOIN news n ON c.news_id = n.news_id ORDER BY c.created_at DESC')->fetchAll();
 $services = $pdo->query('SELECT * FROM services ORDER BY id ASC')->fetchAll();
 $messages = $pdo->query('SELECT * FROM contact_messages ORDER BY created_at DESC')->fetchAll();
 $users = $pdo->query('SELECT u.id, u.name, ut.user_type FROM users u JOIN user_types ut ON u.id = ut.user_id')->fetchAll();
 $admins = array_filter($users, fn($u) => $u['user_type'] === 'Admin');

 $stmtContent = $pdo->prepare('SELECT content FROM page_content WHERE section = ?');
 $heroTitle = 'RK News';
 $aboutText = 'Welcome to RK News.';

 $stmtContent->execute(['hero_title']);
 $row = $stmtContent->fetch();
if ($row) $heroTitle = $row['content'];

 $stmtContent->execute(['about_us']);
 $row = $stmtContent->fetch();
if ($row) $aboutText = $row['content'];

 $pageTitle = 'Admin Dashboard - RK News';
require_once 'includes/header.php';
?>

<main class="container main-content admin-dashboard">
    <h1>Admin Dashboard</h1>

    <section class="admin-section">
        <h2>Manage News</h2>
        <form method="post" action="api/add_news.php" class="admin-form">
            <label>Title</label>
            <input type="text" name="title" required>
            
            <label>Content</label>
            <textarea name="content" rows="5" required></textarea>
            
            <label>Media Type</label>
            <select name="media_type">
                <option value="image">Image</option>
                <option value="video">Video (MP4/WebM)</option>
                <option value="audio">Audio (MP3/WAV)</option>
            </select>
            
            <label>Media URL (Link to Image, Video, or Audio file)</label>
            <input type="text" name="media_url" placeholder="https://example.com/media.mp4" required>
            
            <button type="submit" class="btn btn-primary">Add News</button>
        </form>

        <h3>News List</h3>
        <ul class="item-list">
            <?php foreach ($news as $item): ?>
                <li>
                    <strong><?php echo htmlspecialchars($item['title']); ?></strong>
                    
                    <form method="post" action="api/edit_news.php" class="inline-form">
                        <input type="hidden" name="news_id" value="<?php echo $item['news_id']; ?>">
                        
                        <div style="margin-bottom: 5px;">
                            <input type="text" name="title" value="<?php echo htmlspecialchars($item['title']); ?>" placeholder="New title" style="width: 100%; box-sizing: border-box;">
                        </div>
                        
                        <div style="margin-bottom: 5px;">
                            <textarea name="content" rows="2" placeholder="New content" style="width: 100%; box-sizing: border-box;"><?php echo htmlspecialchars($item['content']); ?></textarea>
                        </div>

                        <div style="margin-bottom: 5px;">
                            <input type="text" name="media_url" value="<?php echo htmlspecialchars($item['media_url'] ?? ''); ?>" placeholder="Image/Video URL" style="width: 70%; box-sizing: border-box;">
                            <select name="media_type" style="width: 25%; box-sizing: border-box;">
                                <option value="image" <?php echo ($item['media_type'] ?? '') === 'image' ? 'selected' : ''; ?>>Image</option>
                                <option value="video" <?php echo ($item['media_type'] ?? '') === 'video' ? 'selected' : ''; ?>>Video</option>
                                <option value="audio" <?php echo ($item['media_type'] ?? '') === 'audio' ? 'selected' : ''; ?>>Audio</option>
                            </select>
                        </div>

                        <button type="submit" class="btn btn-small">Update</button>
                    </form>

                    <form method="post" action="api/delete_news.php" class="inline-form">
                        <input type="hidden" name="news_id" value="<?php echo $item['news_id']; ?>">
                        <button type="submit" class="btn btn-small btn-danger">Delete</button>
                    </form>
                </li>
            <?php endforeach; ?>
        </ul>
    </section>

    <section class="admin-section">
        <h2>Manage Comments</h2>
        <ul class="item-list">
            <?php foreach ($comments as $c): ?>
                <li>
                    <strong><?php echo htmlspecialchars($c['name']); ?></strong>
                    on "<?php echo htmlspecialchars($c['title']); ?>":
                    <?php echo htmlspecialchars(mb_substr($c['content'], 0, 100)); ?>...
                    <form method="post" action="api/delete_comment.php" class="inline-form">
                        <input type="hidden" name="comment_id" value="<?php echo $c['id']; ?>">
                        <button type="submit" class="btn btn-small btn-danger">Delete</button>
                    </form>
                </li>
            <?php endforeach; ?>
        </ul>
    </section>

    <section class="admin-section">
        <h2>Landing Page Content</h2>
        <form method="post">
            <input type="hidden" name="update_content" value="1">
            <label>Hero Title</label>
            <input type="text" name="section" value="hero_title" readonly>
            <input type="text" name="content" value="<?php echo htmlspecialchars($heroTitle); ?>">
            <button type="submit" class="btn btn-small">Update Hero Title</button>
        </form>

        <form method="post">
            <input type="hidden" name="update_content" value="1">
            <label>About Us</label>
            <input type="text" name="section" value="about_us" readonly>
            <textarea name="content" rows="5"><?php echo htmlspecialchars($aboutText); ?></textarea>
            <button type="submit" class="btn btn-small">Update About Us</button>
        </form>
    </section>

    <section class="admin-section">
        <h2>Services</h2>
        <form method="post" action="api/add_service.php" class="admin-form">
            <label>Title</label>
            <input type="text" name="title" required>
            <label>Description</label>
            <textarea name="description" rows="3" required></textarea>
            <button type="submit" class="btn btn-primary">Add Service</button>
        </form>

        <h3>Existing Services</h3>
        <ul class="item-list">
            <?php foreach ($services as $s): ?>
                <li>
                    <strong><?php echo htmlspecialchars($s['title']); ?></strong>
                    <?php echo htmlspecialchars($s['description']); ?>
                    <form method="post" action="api/delete_service.php" class="inline-form">
                        <input type="hidden" name="service_id" value="<?php echo $s['id']; ?>">
                        <button type="submit" class="btn btn-small btn-danger">Delete</button>
                    </form>
                </li>
            <?php endforeach; ?>
        </ul>
    </section>

    <section class="admin-section">
        <h2>Manage Admins</h2>
        <h3>Existing Admins</h3>
        <ul class="item-list">
            <?php foreach ($admins as $a): ?>
                <li>
                    <?php echo htmlspecialchars($a['name']); ?> (ID: <?php echo $a['id']; ?>)
                </li>
            <?php endforeach; ?>
        </ul>

        <h3>Add New Admin</h3>
        <form method="post" action="api/add_admin.php" class="admin-form">
            <label>Name</label>
            <input type="text" name="name" required>
            <label>Password</label>
            <input type="password" name="password" required>
            <button type="submit" class="btn btn-primary">Add Admin</button>
        </form>
    </section>

    <section class="admin-section">
        <h2>Contact Messages</h2>
        <ul class="item-list">
            <?php foreach ($messages as $m): ?>
                <li>
                    <strong><?php echo htmlspecialchars($m['name']); ?></strong>
                    &lt;<?php echo htmlspecialchars($m['email']); ?>&gt;
                    <small><?php echo htmlspecialchars($m['created_at']); ?></small>
                    <p><?php echo nl2br(htmlspecialchars($m['message'])); ?></p>
                </li>
            <?php endforeach; ?>
        </ul>
    </section>
</main>

<?php require_once 'includes/footer.php'; ?>