<?php

require_once 'db_connect.php';

session_start();

 $stmtContent = $pdo->prepare('SELECT content FROM page_content WHERE section = ?');
 $heroTitle = 'RK News';
 $aboutText = 'Welcome to RK News.';

 $stmtContent->execute(['hero_title']);
 $row = $stmtContent->fetch();
if ($row) {
    $heroTitle = $row['content'];
}

 $stmtContent->execute(['about_us']);
 $row = $stmtContent->fetch();
if ($row) {
    $aboutText = $row['content'];
}


 $services = $pdo->query('SELECT * FROM services ORDER BY id ASC')->fetchAll();

 $search = trim($_GET['q'] ?? '');
if ($search) {
    $stmtNews = $pdo->prepare('
        SELECT * FROM news
        WHERE title LIKE ? OR content LIKE ?
        ORDER BY created_at DESC
    ');
    $param = "%$search%";
    $stmtNews->execute([$param, $param]);
} else {
    $stmtNews = $pdo->query('SELECT * FROM news ORDER BY created_at DESC');
}
 $newsItems = $stmtNews->fetchAll();

 $pageTitle = 'Home - RK News';
require_once 'includes/header.php';
?>

<main class="container main-content">

    <section id="hero" class="hero-section">
        <h1><?php echo htmlspecialchars($heroTitle); ?></h1>
        <p>Latest updates and news from all entertainment in the world, delivered to you.</p>
    </section>

    <section class="search-section">
        <form method="get" class="search-form">
            <input type="text" name="q" id="search-input" placeholder="Search news..." value="<?php echo htmlspecialchars($search); ?>">
            <button type="submit" class="btn btn-secondary">Search</button>
        </form>
    </section>

    <section id="news-feed" class="news-feed">
        <h2>Latest News</h2>
        <div class="news-grid">
            <?php if ($newsItems): ?>
                <?php foreach ($newsItems as $news): ?>
                    <article class="news-card">
                      
                        <?php if ($news['media_url']): ?>
                            <div class="media-container">
                                <?php if ($news['media_type'] === 'image'): ?>
                                    <img src="<?php echo htmlspecialchars($news['media_url']); ?>" alt="News Image" class="news-image">
                                <?php elseif ($news['media_type'] === 'video'): ?>
                                    <video controls class="news-media">
                                        <source src="<?php echo htmlspecialchars($news['media_url']); ?>" type="video/mp4">
                                        Your browser does not support the video tag.
                                    </video>
                                <?php elseif ($news['media_type'] === 'audio'): ?>
                                    <div class="audio-wrapper">
                                        <audio controls class="news-media">
                                            <source src="<?php echo htmlspecialchars($news['media_url']); ?>" type="audio/mpeg">
                                            Your browser does not support the audio element.
                                        </audio>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                   

                        <div class="news-body">
                            <h3 class="news-title">
                                <a href="news_details.php?news_id=<?php echo $news['news_id']; ?>">
                                    <?php echo htmlspecialchars($news['title']); ?>
                                </a>
                            </h3>
                            <p class="news-preview">
                                <?php echo htmlspecialchars(mb_substr($news['content'], 0, 150)); ?>...
                            </p>

                            <a href="news_details.php?news_id=<?php echo $news['news_id']; ?>" class="btn btn-small">Read More</a>

                        </div>
                    </article>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No news found.</p>
            <?php endif; ?>
        </div>
    </section>

    <section id="about" class="section">
        <h2>About Us</h2>
        <p><?php echo nl2br(htmlspecialchars($aboutText)); ?></p>
    </section>

    <section id="services" class="section">
        <h2>Our Services</h2>
        <div class="services-grid">
            <?php if ($services): ?>
                <?php foreach ($services as $service): ?>
                    <div class="service-card">
                        <h3><?php echo htmlspecialchars($service['title']); ?></h3>
                        <p><?php echo nl2br(htmlspecialchars($service['description'])); ?></p>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No services available yet.</p>
            <?php endif; ?>
        </div>
    </section>
</main>

<?php require_once 'includes/footer.php'; ?>