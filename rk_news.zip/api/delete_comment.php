<?php

require_once '../db_connect.php';

session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

 $commentId = $_POST['comment_id'] ?? 0;

if (!$commentId) {
    header('Location: ../index.php');
    exit;
}


 $stmt = $pdo->prepare('SELECT user_id, news_id FROM comments WHERE id = ?');
 $stmt->execute([$commentId]);
 $comment = $stmt->fetch();

if (!$comment) {
    header('Location: ../index.php');
    exit;
}

 $isAdmin = ($_SESSION['user_type'] === 'Admin');
 $isOwner = ($comment['user_id'] == $_SESSION['user_id']);

if (!$isOwner && !$isAdmin) {
    header('Location: ../index.php');
    exit;
}

 $stmtDelete = $pdo->prepare('DELETE FROM comments WHERE id = ?');
 $stmtDelete->execute([$commentId]);

 $newsId = $comment['news_id'];

header('Location: ../news_details.php?news_id=' . urlencode($newsId));
exit;