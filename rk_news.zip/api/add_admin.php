<?php

require_once '../db_connect.php';

session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'Admin') {
    header('Location: ../index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($name && $password) {
       
        $stmt = $pdo->prepare('SELECT id FROM users WHERE name = ?');
        $stmt->execute([$name]);
        $existing = $stmt->fetch();

        if ($existing) {
            
            $stmtType = $pdo->prepare('
                INSERT INTO user_types (user_id, user_type)
                VALUES (?, ?)
                ON DUPLICATE KEY UPDATE user_type = ?
            ');
            $stmtType->execute([$existing['id'], 'Admin', 'Admin']);
        } else {
           
            $stmtUser = $pdo->prepare('INSERT INTO users (name, password) VALUES (?, ?)');
            $stmtUser->execute([$name, $password]);
            $userId = $pdo->lastInsertId();

            $stmtType = $pdo->prepare('INSERT INTO user_types (user_id, user_type) VALUES (?, ?)');
            $stmtType->execute([$userId, 'Admin']);
        }
    }
}

header('Location: ../admin_dashboard.php');
exit;