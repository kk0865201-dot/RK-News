<?php

require_once '../db_connect.php';

session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

 $commentId = $_POST['comment_id'] ?? 0;
 $content = $_POST['content'] ?? '';
 $newsId = $_POST['news_id'] ?? 0;

if (!$commentId || !$content) {
    header('Location: ../index.php');
    exit;
}

 $stmt = $pdo->prepare('SELECT user_id FROM comments WHERE id = ?');
 $stmt->execute([$commentId]);
 $comment = $stmt->fetch();

if (!$comment) {
    echo 'Comment not found.';
    exit;
}

 $isAdmin = ($_SESSION['user_type'] === 'Admin');
 $isOwner = ($comment['user_id'] == $_SESSION['user_id']);

if (!$isOwner && !$isAdmin) {
    header('Location: ../index.php');
    exit;
}

 $stmtUpdate = $pdo->prepare('UPDATE comments SET content = ? WHERE id = ?');
 $stmtUpdate->execute([$content, $commentId]);

header('Location: ../news_details.php?news_id=' . urlencode($newsId));
exit;