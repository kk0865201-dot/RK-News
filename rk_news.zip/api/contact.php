<?php

header('Content-Type: application/json');

require_once '../db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if ($name && $email && $message) {
        $stmt = $pdo->prepare('INSERT INTO contact_messages (name, email, message) VALUES (?, ?, ?)');
        if ($stmt->execute([$name, $email, $message])) {
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to save message.']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Please fill all fields.']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request.']);
}