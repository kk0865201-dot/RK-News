<?php

require_once '../db_connect.php';

session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'Admin') {
    header('Location: ../index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'] ?? '';
    $description = $_POST['description'] ?? '';

    if ($title && $description) {
        $stmt = $pdo->prepare('INSERT INTO services (title, description) VALUES (?, ?)');
        $stmt->execute([$title, $description]);
    }
}

header('Location: ../admin_dashboard.php');
exit;