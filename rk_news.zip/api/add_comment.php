<?php

require_once '../db_connect.php';

session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newsId = $_POST['news_id'] ?? 0;
    $content = $_POST['content'] ?? '';
    $userId = $_SESSION['user_id'];

    if ($newsId && $content) {
        $stmt = $pdo->prepare('INSERT INTO comments (user_id, news_id, content) VALUES (?, ?, ?)');
        $stmt->execute([$userId, $newsId, $content]);
    }
}

header('Location: ../news_details.php?news_id=' . urlencode($newsId));
exit;