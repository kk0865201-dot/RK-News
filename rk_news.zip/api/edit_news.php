<?php

require_once '../db_connect.php';

session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'Admin') {
    header('Location: ../index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newsId = $_POST['news_id'] ?? 0;
    $title = $_POST['title'] ?? '';
    $content = $_POST['content'] ?? '';
    $mediaUrl = $_POST['media_url'] ?? ''; 
    $mediaType = $_POST['media_type'] ?? 'image'; 

    if ($newsId && ($title || $content)) {
        $stmt = $pdo->prepare('UPDATE news SET title = ?, content = ?, media_url = ?, media_type = ? WHERE news_id = ?');
        $stmt->execute([$title, $content, $mediaUrl, $mediaType, $newsId]);
    }
}

header('Location: ../admin_dashboard.php');
exit;