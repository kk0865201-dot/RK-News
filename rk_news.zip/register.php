<?php

require_once 'db_connect.php';

session_start();

 $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $password = $_POST['password'] ?? '';
    $type = $_POST['type'] ?? 'User';

    if ($name && $password) {

        $stmt = $pdo->prepare('SELECT id FROM users WHERE name = ?');
        $stmt->execute([$name]);
        if ($stmt->fetch()) {
            $error = 'Name is already taken.';
        } else {

            $stmt = $pdo->prepare('INSERT INTO users (name, password) VALUES (?, ?)');
            if ($stmt->execute([$name, $password])) {
                $userId = $pdo->lastInsertId();
                $stmtType = $pdo->prepare('INSERT INTO user_types (user_id, user_type) VALUES (?, ?)');
                $stmtType->execute([$userId, $type]);

                $_SESSION['user_id'] = $userId;
                $_SESSION['name'] = $name;
                $_SESSION['user_type'] = $type;

                header('Location: index.php');
                exit;
            } else {
                $error = 'Registration failed. Please try again.';
            }
        }
    } else {
        $error = 'Please enter name and password.';
    }
}

 $pageTitle = 'Register - RK News';
require_once 'includes/header.php';
?>

<main class="container main-content">
    <h1>Register</h1>

    <?php if ($error): ?>
        <p class="error"><?php echo htmlspecialchars($error); ?></p>
    <?php endif; ?>

    <form method="post" class="auth-form">
        <label for="name">Name</label>
        <input type="text" name="name" id="name" required>

        <label for="password">Password</label>
        <input type="password" name="password" id="password" required>

        <label for="type">Account Type</label>
        <select name="type" id="type">
            <option value="User">User</option>
        </select>

        <button type="submit" class="btn btn-primary">Register</button>
    </form>

    <p>Already have an account? <a href="login.php">Login here</a>.</p>
</main>

<?php require_once 'includes/footer.php'; ?>