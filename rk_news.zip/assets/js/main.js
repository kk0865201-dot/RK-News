document.addEventListener('DOMContentLoaded', function () {

    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', function (e) {
            e.preventDefault();

            const formData = new FormData(contactForm);
            const statusEl = document.getElementById('contact-message-status');

            fetch('api/contact.php', {
                method: 'POST',
                body: formData
            })
                .then(res => res.json())
                .then(data => {
                    if (data.status === 'success') {
                        statusEl.textContent = 'Message sent successfully.';
                        statusEl.style.color = 'green';
                        contactForm.reset();
                    } else {
                        statusEl.textContent = data.message || 'Error sending message.';
                        statusEl.style.color = 'red';
                    }
                })
                .catch(() => {
                    statusEl.textContent = 'Error sending message.';
                    statusEl.style.color = 'red';
                });
        });
    }

    const editButtons = document.querySelectorAll('.btn-edit-comment');
    editButtons.forEach(btn => {
        btn.addEventListener('click', function () {
            const commentId = this.getAttribute('data-comment-id');
            const commentEl = document.getElementById('comment-' + commentId);
            const textP = commentEl.querySelector('p');

            const newContent = prompt('Edit your comment:', textP.innerText.trim());
            if (newContent && newContent.trim() !== '') {
                const formData = new FormData();
                formData.append('comment_id', commentId);
                formData.append('content', newContent.trim());
                formData.append('news_id', new URLSearchParams(window.location.search).get('news_id'));

                fetch('api/edit_comment.php', {
                    method: 'POST',
                    body: formData
                })
                    .then(() => {
             
                        textP.innerText = newContent.trim();
                    })
                    .catch(() => {
                        alert('Failed to update comment.');
                    });
            }
        });
    });
});