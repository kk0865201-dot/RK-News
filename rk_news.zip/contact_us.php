<?php

require_once 'db_connect.php';

session_start();

require_once 'includes/header.php';
?>

<main class="container main-content">
    
    <section id="contact" class="section">
        <h2>Contact Us</h2>
        <form id="contact-form" class="contact-form">
            <label for="contact-name">Name</label>
            <input type="text" name="name" id="contact-name" required>

            <label for="contact-email">Email</label>
            <input type="email" name="email" id="contact-email" required>

            <label for="contact-message">Message</label>
            <textarea name="message" id="contact-message" rows="5" required></textarea>

            <button type="submit" class="btn btn-primary">Send Message</button>
            <p id="contact-message-status"></p>
        </form>
    </section>
</main>

<?php require_once 'includes/footer.php'; ?>