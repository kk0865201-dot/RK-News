<?php

require_once 'db_connect.php';

session_start();

 $newsId = $_GET['news_id'] ?? 0;
if (!$newsId) {
    header('Location: index.php');
    exit;
}

 $stmt = $pdo->prepare('SELECT * FROM news WHERE news_id = ?');
 $stmt->execute([$newsId]);
 $news = $stmt->fetch();

if (!$news) {
    echo 'News not found.';
    exit;
}

 $stmtComments = $pdo->prepare('
    SELECT c.*, u.name
    FROM comments c
    JOIN users u ON c.user_id = u.id
    WHERE c.news_id = ?
    ORDER BY c.created_at ASC
');
 $stmtComments->execute([$newsId]);
 $comments = $stmtComments->fetchAll();

 $pageTitle = htmlspecialchars($news['title']) . ' - RK News';
require_once 'includes/header.php';
?>

<main class="container main-content">
    <article class="single-news">
      
        <?php if ($news['media_url']): ?>
            <div class="media-container-full">
                <?php if ($news['media_type'] === 'image'): ?>
                    <img src="<?php echo htmlspecialchars($news['media_url']); ?>" alt="" class="news-image-full">
                <?php elseif ($news['media_type'] === 'video'): ?>
                    <video controls class="news-media-full" style="width:100%; max-height:500px;">
                        <source src="<?php echo htmlspecialchars($news['media_url']); ?>" type="video/mp4">
                        Your browser does not support the video tag.
                    </video>
                <?php elseif ($news['media_type'] === 'audio'): ?>
                    <div class="audio-wrapper">
                        <audio controls style="width: 100%;">
                            <source src="<?php echo htmlspecialchars($news['media_url']); ?>" type="audio/mpeg">
                            Your browser does not support the audio element.
                        </audio>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <h1><?php echo htmlspecialchars($news['title']); ?></h1>
        
        <p class="news-meta">Posted at <?php echo htmlspecialchars($news['created_at']); ?></p>
        <div class="news-content">
            <?php echo nl2br(htmlspecialchars($news['content'])); ?>
        </div>
    </article>

    <section class="comments-section">
        <h2>Comments</h2>

        <?php if (isset($_SESSION['user_id'])): ?>
            <form method="post" action="api/add_comment.php" class="comment-form">
                <input type="hidden" name="news_id" value="<?php echo $news['news_id']; ?>">
                <label for="comment-content">Add a comment</label>
                <textarea name="content" id="comment-content" rows="3" required></textarea>
                <button type="submit" class="btn btn-primary">Post Comment</button>
            </form>
        <?php else: ?>
            <p><a href="login.php">Login</a> to leave a comment.</p>
        <?php endif; ?>

        <div class="comments-list">
            <?php if ($comments): ?>
                <?php foreach ($comments as $comment): ?>
                    <div class="comment" id="comment-<?php echo $comment['id']; ?>">
                        <div class="comment-header">
                            <strong><?php echo htmlspecialchars($comment['name']); ?></strong>
                            <small><?php echo htmlspecialchars($comment['created_at']); ?></small>
                        </div>
                        <p><?php echo nl2br(htmlspecialchars($comment['content'])); ?></p>

                        <?php if (isset($_SESSION['user_id'])): ?>
                            <?php
                            $isOwner = ($comment['user_id'] == $_SESSION['user_id']);
                            $isAdmin = ($_SESSION['user_type'] === 'Admin');
                            ?>
                            <?php if ($isOwner || $isAdmin): ?>
                                <div class="comment-actions">
                                    <?php if ($isOwner || $isAdmin): ?>
                                        <button class="btn btn-small btn-edit-comment"
                                            data-comment-id="<?php echo $comment['id']; ?>">Edit</button>
                                    <?php endif; ?>
                                    <form method="post" action="api/delete_comment.php" class="inline-form">
                                        <input type="hidden" name="comment_id" value="<?php echo $comment['id']; ?>">
                                        <button type="submit" class="btn btn-small btn-danger">Delete</button>
                                    </form>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No comments yet.</p>
            <?php endif; ?>
        </div>
    </section>
</main>

<?php require_once 'includes/footer.php'; ?>