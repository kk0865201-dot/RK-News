<?php
// login.php
require_once 'db_connect.php';

session_start();

 $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($name && $password) {
        // plain-text password as requested
        $stmt = $pdo->prepare('
            SELECT u.id, u.name, u.password, ut.user_type
            FROM users u
            JOIN user_types ut ON u.id = ut.user_id
            WHERE u.name = ?
        ');
        $stmt->execute([$name]);
        $user = $stmt->fetch();

        if ($user && $user['password'] === $password) {
            // login success
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['user_type'] = $user['user_type'];

            // redirect based on role
            if ($user['user_type'] === 'Admin') {
                header('Location: admin_dashboard.php');
            } else {
                header('Location: index.php');
            }
            exit;
        } else {
            $error = 'Invalid name or password.';
        }
    } else {
        $error = 'Please enter name and password.';
    }
}

 $pageTitle = 'Login - RK News';
require_once 'includes/header.php';
?>

<main class="container main-content">
    <h1>Login</h1>

    <?php if ($error): ?>
        <p class="error"><?php echo htmlspecialchars($error); ?></p>
    <?php endif; ?>

    <form method="post" class="auth-form">
        <label for="name">Name</label>
        <input type="text" name="name" id="name" required>

        <label for="password">Password</label>
        <input type="password" name="password" id="password" required>

        <button type="submit" class="btn btn-primary">Login</button>
    </form>

    <p>Don't have an account? <a href="register.php">Register here</a>.</p>
</main>

<?php require_once 'includes/footer.php'; ?>