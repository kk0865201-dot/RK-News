<?php

require_once 'db_connect.php';

session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'User') {
    header('Location: login.php');
    exit;
}

 $userId = $_SESSION['user_id'];

 $stmt = $pdo->prepare('
    SELECT c.*, n.title AS news_title
    FROM comments c
    JOIN news n ON c.news_id = n.news_id
    WHERE c.user_id = ?
    ORDER BY c.created_at DESC
');
 $stmt->execute([$userId]);
 $comments = $stmt->fetchAll();

 $pageTitle = 'User Dashboard - RK News';
require_once 'includes/header.php';
?>

<main class="container main-content">
    <h1>Welcome, <?php echo htmlspecialchars($_SESSION['name']); ?></h1>

    <section class="user-comments-section">
        <h2>My Comments</h2>
        <?php if ($comments): ?>
            <div class="comments-list">
                <?php foreach ($comments as $comment): ?>
                    <div class="comment">
                        <div class="comment-header">
                            <strong>On: <?php echo htmlspecialchars($comment['news_title']); ?></strong>
                            <small><?php echo htmlspecialchars($comment['created_at']); ?></small>
                        </div>
                        <p><?php echo nl2br(htmlspecialchars($comment['content'])); ?></p>
                        <a href="news_details.php?news_id=<?php echo $comment['news_id']; ?>#comment-<?php echo $comment['id']; ?>" class="btn btn-small">View</a>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p>You haven't commented yet.</p>
        <?php endif; ?>
    </section>
</main>

<?php require_once 'includes/footer.php'; ?>