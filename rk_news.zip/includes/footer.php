<?php
?>
<footer class="footer">
    <div class="container">
        <p>&copy; <?php echo date('Y'); ?> RK News. All rights reserved. We know a good lawyer, so be careful, and add to that the possibility that Rafa will hold his breath and die!💀!.</p>
    </div>
</footer>
<script src="assets/js/main.js"></script>
</body>
</html>