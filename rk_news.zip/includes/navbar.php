<?php
?>
<nav class="navbar">
    <div class="container navbar-inner">
        <div class="logo">RK News</div>
        <ul class="nav-links">
            <li><a href="index.php">Home</a></li>
            <li><a href="index.php#about">About Us</a></li>
            <li><a href="index.php#services">Services</a></li>
            <li><a href="contact_us.php">Contact Us</a></li>
            <?php if (isset($_SESSION['user_id'])): ?>
                <?php if ($_SESSION['user_type'] === 'Admin'): ?>
                    <li><a href="admin_dashboard.php">Admin Panel</a></li>
                <?php else: ?>
                    <li><a href="user_dashboard.php">My Dashboard</a></li>
                <?php endif; ?>
                <li><a href="logout.php">Logout (<?php echo htmlspecialchars($_SESSION['name']); ?>)</a></li>
            <?php else: ?>
                <li><a href="login.php">Login / Register</a></li>
            <?php endif; ?>
        </ul>
    </div>
</nav>